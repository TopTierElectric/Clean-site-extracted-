# 90-Day Execution Plan (Week-by-Week)

## Week 1 — Foundation
1. Complete 00_Project_Setup.md
2. GBP:
   - Finish GBP/01 and GBP/02
   - Upload first 20 photos (GBP/04)
3. Website:
   - Finish Website/01 (brand name + NAP)
   - Verify Search Console (Tracking/01)
4. Reviews:
   - Create review link + QR code

## Week 2 — Activity & Citations
1. GBP:
   - Start weekly posts (GBP/03)
   - Add 10 Q&As (GBP/05)
2. Citations:
   - Submit Tier 1 directories (10)
3. Website:
   - Improve 2 service pages (Website/02)

## Week 3 — City Pages + More Citations
1. Website:
   - Publish 2 city pages (Website/04)
2. Citations:
   - Submit Tier 2 (10–15)
3. Reviews:
   - Ask every job + follow-up system

## Week 4 — Link Building Starts
1. Backlinks:
   - Outreach to 5 partners (Backlinks/02)
   - Join 1 local org or directory
2. GBP:
   - Continue weekly post + photos
3. Website:
   - Publish 1 blog post (Website/05)

## Weeks 5–8 — Scale
1. Add remaining city pages (aim 5 total)
2. Continue:
   - 1 post/week
   - 3 photos/week
   - 2–4 reviews/month
3. Earn 1 backlink every 2 weeks

## Weeks 9–12 — Optimize
1. Review ranking + Search Console data
2. Improve pages that get impressions but low clicks:
   - Better titles/meta
   - Stronger CTAs
3. Add 1 more blog post
4. Fix any citation inconsistencies found

---

## Success targets by day 90
- 15+ Google reviews
- 40+ GBP photos
- 12 Google posts
- 25–40 citations
- 5–10 local backlinks/mentions
- Brand search: #1 result + visible Knowledge Panel/Maps
