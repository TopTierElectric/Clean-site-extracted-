# Website 01 — Brand Name + NAP Consistency SOP

## Goal
Make your website unmistakably match the name people search, and align NAP with GBP and citations.

---

## Step 1 — Add your exact business name in plain text on the homepage
1. Open your homepage editor (or HTML file).
2. Add a sentence near the top (hero or intro) that includes your exact name.

Copy/paste example (edit your chosen name):
“Top Tier Electrical Services is a licensed and insured electrician serving West Michigan.”

✅ Why: Google reads text. Logos alone are not enough.

---

## Step 2 — Add consistent NAP in the footer
1. Edit the site footer.
2. Include:
   - Business name
   - Phone number (click-to-call)
   - City/State (at minimum)
   - Website link (optional)

Example:
Top Tier Electrical Services • (616) 334-7159 • Serving West Michigan

---

## Step 3 — Add NAP on the Contact page
1. Ensure Contact page includes:
   - Phone
   - Email (if used)
   - Service area list (cities)
2. If you are a service-area business, avoid publishing a street address if you don’t want it public.
3. If you do publish address, ensure it matches GBP exactly.

---

## Step 4 — Match the name across the site
1. Search your site code for “Top Tier Electrical” and “Top Tier Electrical Services”.
2. Ensure it matches your chosen public name (Step 1 of Project Setup).
3. Update any mismatched variants.

---

## Step 5 — Update title tags if needed
1. Homepage title tag should include:
   - Electrician
   - West Michigan
   - Brand

Example:
Electrician in West Michigan | Top Tier Electrical Services

---

## Step 6 — Confirm the website matches GBP
1. Compare:
   - Name
   - Phone
   - Website URL
   - Service area wording (West Michigan)
2. Make them consistent everywhere.

---

## Deliverable check
✅ When you search your business name, Google can connect:
- GBP name
- Website business name text
- Schema business name (see Website 03)
