# Website 04 — Local Landing Pages SOP (Cities in West Michigan)

## Goal
Create city pages that rank for “electrician {city}” searches.

---

## Step 1 — Pick your top 5 cities
Recommended:
1. Holland
2. Grand Rapids
3. Zeeland
4. Grand Haven
5. Muskegon

Write yours here:
- City 1: ________
- City 2: ________
- City 3: ________
- City 4: ________
- City 5: ________

---

## Step 2 — Create 1 page per city
URL format:
- /electrician-holland-mi.html
- /electrician-grand-rapids-mi.html

---

## Step 3 — City page content outline (copy structure)
1. H1: Electrician in {City}, MI
2. 2–3 paragraphs:
   - What you do
   - Why trust you
   - Local mention (neighborhoods/landmarks)
3. Services section (link to service pages)
4. “Common projects in {City}” bullets
5. FAQ section (4–6 Q’s)
6. CTA: Call + Quote form

---

## Step 4 — Avoid duplicate content
Each city page must have:
- Unique intro paragraph
- Unique “Common projects” bullets
- Unique FAQ set or at least partly unique

---

## Step 5 — Link city pages from Service Areas page
1. Update /service-areas.html (or similar)
2. Add a list of city pages with links.

---

## Step 6 — Add city internal links
From service pages, add a section:
“Serving Holland, Grand Rapids, Zeeland...” where each city is linked to its city page.

---

## Step 7 — Indexing
Request indexing in Search Console for each new city page.

---

## Deliverable check
✅ 5 city pages live + linked + indexed.
