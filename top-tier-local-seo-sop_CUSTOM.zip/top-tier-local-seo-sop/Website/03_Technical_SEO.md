# Website 03 — Technical SEO SOP (Schema, Search Console, Speed)

## Goal
Make sure Google can crawl, understand, and trust your site.

---

## Step 1 — Google Search Console setup
1. Go to Google Search Console.
2. Add property:
   - **Domain** property preferred (covers all subdomains).
3. Verify via DNS (your domain host).
4. Submit your sitemap:
   - https://toptier-electrical.com/sitemap.xml
5. Check “Coverage” / “Pages” weekly.

---

## Step 2 — Verify indexing
1. In Search Console:
   - URL Inspection your homepage
2. Confirm:
   - “URL is on Google”
3. If not:
   - Request indexing

---

## Step 3 — LocalBusiness schema check
Your site already has LocalBusiness/Electrician schema.
Do this:
1. Open Google’s Rich Results Test (or Schema validator).
2. Test your homepage URL.
3. Confirm no errors.

### Optional improvement: add city/region as address without street
If you do not want street public:
1. Add this to JSON-LD:
"address": {
  "@type": "PostalAddress",
  "addressLocality": "[Your Base City]",
  "addressRegion": "MI"
}

Use your real base city.

---

## Step 4 — Add “sameAs” links in schema
Include:
- Facebook page
- Any other social profiles
- (Later) Yelp, BBB, etc.

---

## Step 5 — Page speed basics (do these in order)
1. Compress images:
   - Resize large photos to ~1600px wide max
   - Use WebP when possible
2. Use responsive images (srcset) for hero/service images (nice-to-have)
3. Ensure caching headers are set (if on Netlify, configure _headers)
4. Avoid heavy plugins/scripts

---

## Step 6 — Fix broken links (monthly)
1. Use a free crawler (Screaming Frog free version or a web-based checker).
2. Fix any 404 errors or redirect chains.

---

## Step 7 — Add a “Map” embed (only if you publish an address)
If you are a service-area business, you can skip this.
If you have an office:
1. Add a Google Map embed to the contact page.

---

## Deliverable check
✅ Search Console verified, sitemap submitted, key pages indexed, schema validated.
