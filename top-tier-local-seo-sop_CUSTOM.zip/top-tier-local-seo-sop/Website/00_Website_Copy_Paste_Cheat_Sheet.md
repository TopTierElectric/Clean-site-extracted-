# Website 00 — Copy/Paste Cheat Sheet (Top Tier Electrical Services)

---

## Standard NAP for website footer + contact page
**Top Tier Electrical Services**  
Phone: **(616) 334-7159**  
Website: **https://toptier-electrical.com**  
Service area: **West Michigan** (Holland, Grand Rapids, Zeeland, Grand Haven, Muskegon + nearby)

---

## Homepage “brand line” (add in plain text near the top)
“Top Tier Electrical Services is a licensed and insured electrician serving West Michigan.”

---

## Title tag patterns
- Homepage: “Electrician in West Michigan | Top Tier Electrical Services”
- Service pages: “{Service} in West Michigan | Top Tier Electrical Services”
- City pages: “Electrician in {City}, MI | Top Tier Electrical Services”
