# Monthly Checklist (60–90 minutes)

1. Review GBP Insights:
   - Calls
   - Website clicks
   - Direction requests
2. Review Search Console:
   - Top queries
   - Top pages
   - Fix any indexing issues
3. Add 1 new blog post (or update a service page)
4. Build 1–2 local backlinks:
   - Sponsor, partner, association listing
5. Citation audit:
   - Google your business name + phone
   - Fix any incorrect listings
6. Review goals:
   - Reviews gained
   - Photos posted
   - Posts published
   - Keywords improved
