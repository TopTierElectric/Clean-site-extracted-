# Weekly Checklist (30 minutes)

Do this every week (same day):

1. Check GBP:
   - Respond to new reviews
   - Respond to new Q&A
2. Add 1 Google Post
3. Upload 3 new photos
4. Check Search Console:
   - Any errors?
   - Are impressions increasing for brand searches?
5. Ask for reviews:
   - Did you request reviews from every completed job this week?
6. Citations:
   - Create/verify at least 2 listings (until complete)
