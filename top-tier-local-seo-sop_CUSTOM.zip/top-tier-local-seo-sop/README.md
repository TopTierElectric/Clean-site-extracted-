# Top Tier Electrical Services — Local SEO SOP Pack (West Michigan)
**Created:** 2026-02-10

## Your business info (pre-filled)
- **Business name:** Top Tier Electrical Services
- **Website:** https://toptier-electrical.com
- **Phone:** (616) 334-7159

This ZIP contains step-by-step procedures (SOPs) you can follow to get your business to consistently show up at the top for:
- Your *brand search* (people searching your company name)
- Local intent searches (e.g., “electrician near me”, “panel upgrade Holland MI”, “EV charger install Grand Rapids”)

## How to use this pack
1. Start with **00_Project_Setup.md** to lock in your official business name + NAP (Name/Address/Phone) format and baseline measurements.
2. Then execute each folder in this order:
   1) **GBP/** (Google Business Profile)
   2) **Website/**
   3) **Citations/**
   4) **Reviews/**
   5) **Backlinks/**
   6) **Tracking/**
3. Use the checklists in **SOP_Checklists/** weekly/monthly.

## Important note about “implementation”
I cannot log into Google Business Profile or your website to make changes directly.
This pack is an “exact step” implementation guide you (or a helper/VA/SEO) can follow.

## Folder map
- **GBP/**: Everything you do in Google Business Profile (categories, services, posts, photos, Q&A, messaging, reviews).
- **Website/**: On-page + technical SEO changes on your site (brand name consistency, schema, service area pages, speed).
- **Citations/**: Getting listed consistently across major directories and local sources.
- **Reviews/**: A complete system to generate Google reviews consistently and respond to reviews professionally.
- **Backlinks/**: How to earn local links and mentions (prominence) without spam.
- **Tracking/**: How to measure progress with Search Console, UTM, analytics, and rank tracking.
- **SOP_Checklists/**: Weekly/monthly routines to keep momentum.

## Start here
Open **00_Project_Setup.md** and follow the steps in order.
