# 00 Project Setup — Lock the foundations (do this first)

## Goal
Before you change anything, lock your “identity” (business name + phone + website + location wording), and record baselines so you can prove results.

---

## Step 1 — Decide your exact public business name (IMPORTANT)
1. Gather your official documents:
   - Business registration / LLC paperwork
   - Your invoices/estimates
   - Vehicle lettering (if you have it)
   - Your website header/logo text
2. Decide which name you will use *everywhere* publicly.
   - Option A: **Top Tier Electrical**
   - Option B: **Top Tier Electrical Services**
   - Option C: **Top Tier Electrical Services LLC** (usually not necessary on marketing profiles)
3. Rule: your Google Business Profile name must match real-world branding (signage/vehicles/invoices).  
   - Do **not** add extra keywords like “Top Rated Electrician West Michigan” to the name.
4. Write your final chosen name here and keep it consistent:
   - **Chosen public name:** Top Tier Electrical Services

---

## Step 2 — Standardize your NAP format (Name/Address/Phone)
1. Choose ONE format and use it everywhere:
   - **Name:** (from Step 1)
   - **Phone:** (e.g., 616-334-7159) — use this exact format everywhere
   - **Website:** https://toptier-electrical.com (exactly)
2. Decide how you will handle your address:
   - If you do NOT want your street address public (service-area business):  
     - You can list **City, MI** on your website and use service areas in GBP.
   - If you DO have a shop/office where customers can visit:
     - Use the full address consistently everywhere.
3. Write your standard here:
   - **Standard Name:** Top Tier Electrical Services
   - **Standard Phone:** (616) 334-7159
   - **Standard Website:** https://toptier-electrical.com
   - **Address policy:** (Service-area only OR publish full address) ______________________

---

## Step 3 — Create a master tracking folder
1. Create a Google Drive folder (or local folder) named:
   - “Top Tier — Local SEO”
2. Inside it, create subfolders:
   - 01 GBP Screenshots
   - 02 Website Screenshots
   - 03 Citations
   - 04 Reviews
   - 05 Backlinks
   - 06 Reports

---

## Step 4 — Record baseline screenshots (15 minutes)
### Baseline A: Brand search
1. Open an Incognito/Private window.
2. Search:
   - “Top Tier Electrical”
   - “Top Tier Electrical Services”
3. Take screenshots of:
   - The full page results
   - The right-side Knowledge Panel / Maps pack (if it appears)
   - Where your website appears (position)
4. Save screenshots in **01 GBP Screenshots**.

### Baseline B: 3 “money” searches
In Incognito, search 3 terms you care about (example):
- “electrician Holland MI”
- “panel upgrade Grand Rapids”
- “EV charger installation West Michigan”
Screenshot results.

---

## Step 5 — Get access to the right accounts/tools
### Google Business Profile
1. Go to Google and search “Google Business Profile”.
2. Click “Manage now”.
3. Confirm you can:
   - Edit profile
   - Read insights
   - Add posts
   - Respond to reviews

### Google Search Console (Website)
1. Go to Google Search Console.
2. Add your website domain.
3. Verify ownership (DNS is best).

### Google Analytics (Optional but recommended)
1. Create GA4 property for your domain.
2. Install tracking code (or via Google Tag Manager).

---

## Step 6 — Create your “single source of truth” sheet
1. Open **Citations/citation-tracker-template.csv** (included).
2. Upload it to Google Sheets.
3. This becomes your “NAP & directory” tracker.

---

## Step 7 — Define your 90-day goals (write them down)
Recommended starter goals:
- Google reviews: +15
- GBP photos: +40
- Google Posts: 1 per week (12 posts)
- Citations: 25–40 accurate listings
- Backlinks: 5–10 local links/mentions
- Brand search: appear #1 organically and in Knowledge Panel

Write your goals here:
- Reviews goal: ________
- Citations goal: ________
- Posts goal: ________
- Photos goal: ________
- Backlinks goal: ________
