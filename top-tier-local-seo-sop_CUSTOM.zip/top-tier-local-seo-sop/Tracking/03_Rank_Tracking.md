# Tracking 03 — Rank Tracking SOP

## Goal
Track improvement for:
- Brand search
- Top “money” keywords

---

## Step 1 — Choose your keyword list (start with 10)
Brand:
1. Top Tier Electrical
2. Top Tier Electrical Services

Local intent (examples):
3. electrician Holland MI
4. electrician Grand Rapids MI
5. panel upgrade Holland MI
6. panel upgrade Grand Rapids
7. EV charger installation Holland MI
8. EV charger installation Grand Rapids
9. electrical troubleshooting Holland MI
10. lighting installation West Michigan

---

## Step 2 — Pick a tracking method
Option A: Paid tools (recommended)
- BrightLocal
- Whitespark
- Local Falcon (map grid)

Option B: Manual (free)
1. Incognito search each keyword weekly.
2. Screenshot results.
3. Record:
   - Map pack position
   - Organic position

---

## Step 3 — Report cadence
- Weekly: quick check of 10 keywords
- Monthly: deeper review and adjust plan
