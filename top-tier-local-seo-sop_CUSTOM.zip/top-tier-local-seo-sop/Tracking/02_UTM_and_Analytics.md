# Tracking 02 — UTM + Analytics SOP

## Goal
Know exactly how many leads come from GBP vs website vs directories.

---

## Step 1 — Set a UTM on your GBP website link (optional but recommended)
WARNING: Use the same base URL everywhere. UTMs can create NAP inconsistencies if you use different URLs across citations.

Best practice:
- Use UTM ONLY on GBP website link.
- Keep citations using the clean URL (no UTM).

Example GBP URL:
https://toptier-electrical.com/?utm_source=google&utm_medium=organic&utm_campaign=gbp

---

## Step 2 — Set up Google Analytics (GA4)
1. Create GA4 property.
2. Install tag on website (or via Google Tag Manager).
3. Confirm real-time visits work.

---

## Step 3 — Track conversions
Minimum:
1. Click-to-call events (phone link clicks)
2. Form submissions
3. Quote requests

If you can’t set up events, at least track:
- Number of calls from GBP insights
- Number of form submissions from email

---

## Step 4 — Monthly report
Every month record:
- GBP calls
- GBP website clicks
- Website organic traffic
- New reviews
- Rankings for top keywords
