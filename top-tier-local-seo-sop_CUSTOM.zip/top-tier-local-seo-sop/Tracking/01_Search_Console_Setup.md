# Tracking 01 — Google Search Console Setup (Exact Steps)

## Goal
See what Google queries you show for, and ensure your pages are indexed.

---

## Step 1 — Add your property
1. Go to Google Search Console.
2. Click **Add property**.
3. Choose **Domain**.
4. Enter your domain: toptier-electrical.com
5. Verify via DNS:
   - Copy TXT record
   - Add to your domain host
   - Click Verify

---

## Step 2 — Submit sitemap
1. Left menu → **Sitemaps**
2. Enter: sitemap.xml
3. Submit

---

## Step 3 — Inspect and index key pages
1. URL inspection:
   - Homepage
   - Services page
   - Each service page
2. Request indexing if needed.

---

## Step 4 — Weekly routine
Every Monday:
1. Performance → Search results:
   - Filter for Queries containing your brand name
   - Track impressions/clicks
2. Pages report:
   - Ensure no important pages are “Excluded” unexpectedly

---

## Deliverable check
✅ Search Console is live and collecting data.
