# Citations 03 — Submission Workflow (Exact Steps)

## Goal
Build citations systematically without losing track.

---

## Step 1 — Open the citation tracker
1. Open **citation-tracker-template.csv** in Google Sheets.
2. Add columns if you want (login email, notes).

---

## Step 2 — Create a “submission batch” plan
Batch 1 (Week 1): Tier 1 directories (10 listings)  
Batch 2 (Week 2): Tier 2 + local orgs (10–15 listings)  
Batch 3 (Week 3–4): Niche/local + cleanup (5–15 listings)

---

## Step 3 — For each directory (repeatable checklist)
1. Search Google: “{DirectoryName} add business listing”
2. Open official listing page.
3. Search for your business.
4. If found:
   - Claim listing
   - Verify ownership
   - Fix NAP to match your standard
5. If not found:
   - Create listing
6. Upload:
   - Logo
   - 5–10 job photos
7. Add categories:
   - Electrician (primary)
8. Add service areas.
9. Add business description.
10. Publish.
11. Update tracker:
   - Date submitted
   - Status (Pending/Live)
   - Listing URL
   - Notes

---

## Step 4 — Verification follow-ups
1. Some directories send postcards/emails/calls.
2. Check daily for 7 days after submission.
3. Complete verification promptly.

---

## Step 5 — Consistency audit (monthly)
1. Google your business name + phone.
2. Open every directory result you find.
3. Fix:
   - Wrong phone
   - Wrong website
   - Wrong business name
   - Duplicate profiles

---

## Success criteria
✅ Every listing shows the SAME:
- Business name
- Phone
- Website
- Service area (West Michigan)
