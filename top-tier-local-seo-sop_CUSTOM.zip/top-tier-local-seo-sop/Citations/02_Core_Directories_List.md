# Citations 02 — Core Directory List (Prioritized)

## Goal
Get listed on high-value directories first (accuracy over volume).

---

## Tier 1 (do these first)
1. Bing Places
2. Apple Business Register (Apple Maps)
3. Yelp
4. Facebook Business Page (ensure About info matches NAP)
5. BBB (Better Business Bureau) — listing or profile
6. Angi (Angie's List)
7. HomeAdvisor
8. Thumbtack
9. Nextdoor (claim business profile if available)
10. YellowPages (YP.com)

---

## Tier 2 (nice-to-have)
11. Manta
12. Chamber of Commerce directory (your local chamber)
13. Local trade association directories (IEC, ABC, etc.)
14. MapQuest / locale sites that still show business lists

---

## Step-by-step for each directory
1. Create account.
2. Search for your business first (it may already exist).
3. If it exists:
   - Claim it
   - Correct NAP
4. If it doesn’t exist:
   - Create listing
5. Add:
   - Categories (Electrician)
   - Service areas
   - Description
   - Photos
6. Save login details in your secure password manager.
7. Mark status in your citation tracker sheet.

---

## Success criteria
✅ 25+ accurate citations with matching NAP and website.
