# Citations 01 — NAP Standard (Copy/Paste)

## Goal
Your Name / Address / Phone must match everywhere.

Fill in and copy/paste this into every directory listing:

**Business name:** Top Tier Electrical Services  
**Phone:** (616) 334-7159  
**Website:** https://toptier-electrical.com  

**Address policy (choose one):**
- Service-area business (no public street address)
- Publish full address

If publishing full address:
**Street:** ______________________________  
**City:** ______________________________  
**State:** MI  
**ZIP:** ______________________________  

**Short business description (Directory version, 150–250 chars):**
Top Tier Electrical Services is a licensed and insured electrician serving West Michigan. Panel upgrades, EV chargers, lighting, troubleshooting, and reliable electrical repairs.

**Long description (300–750 chars):**
Top Tier Electrical Services provides licensed electrical service across West Michigan, including Holland, Grand Rapids, Zeeland, Grand Haven, and Muskegon. We handle panel upgrades, EV charger installs, lighting, troubleshooting, code corrections, and more. Call (616) 334-7159 for clear estimates and clean workmanship.

---

## Rules (don’t skip)
1. Use the SAME phone number everywhere.
2. Use the SAME website URL everywhere.
3. Use the SAME spelling/punctuation in your business name everywhere.
4. If you change your GBP name, update citations to match (and vice versa).
