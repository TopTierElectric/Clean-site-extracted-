# Reviews 03 — QR Code Setup (Exact Steps)

## Goal
Make it frictionless for customers to leave a review.

---

## Step 1 — Get your Google review link
1. Open GBP Manager.
2. Click **Ask for reviews**.
3. Copy your review link.

---

## Step 2 — Create a QR code
Option A (simple):
1. Go to any reputable QR code generator.
2. Paste your review link.
3. Download as PNG.

Option B (best for print):
1. Download as SVG (vector) if available.

---

## Step 3 — Use it in the real world
Print the QR code on:
- Business cards
- Invoice/estimate PDF
- A small “Review us on Google” card you leave behind

Text to include on the card:
“Scan to leave a Google review — it helps local West Michigan homeowners find us. Thank you!”

---

## Step 4 — Test it
1. Scan QR code with your phone camera.
2. Confirm it opens the review screen directly.

---

## Step 5 — Track results
Over time, ask customers:
“Did the QR code work okay?”
If not, shorten the link or remake the code.
