# GBP 06 — Reviews System SOP (Exact Steps)

## Goal
Generate consistent Google reviews (without violating policies) and respond professionally.

---

## Step 1 — Create your Google review link
1. Open GBP Manager.
2. Find **Ask for reviews** (or “Get more reviews”).
3. Copy the short review link.

---

## Step 2 — Build your “review request” process (every job)
### When to ask
1. Ask at job completion when the customer is happy.
2. Then send a follow-up text within 2 hours.

### What to say (in person)
“Thanks again — if you felt we did a great job, would you be willing to leave us a quick Google review? It really helps a small local business.”

---

## Step 3 — Text message template (copy/paste)
“Hi {FirstName}, this is {YourName} with Top Tier Electrical Services. Thanks again for having us out today. If you have 60 seconds, could you leave us a quick Google review? Here’s the link: {ReviewLink}”

---

## Step 4 — Email template (copy/paste)
Subject: Quick favor — your feedback helps

Hi {FirstName},  
Thanks again for choosing Top Tier Electrical Services. If you have a moment, we’d really appreciate a quick Google review — it helps other West Michigan homeowners find us.  
{ReviewLink}

Thank you,  
{YourName}  
Top Tier Electrical Services  
(616) 334-7159

---

## Step 5 — What NOT to do (avoid penalties)
1. Don’t offer cash/gifts in exchange for reviews.
2. Don’t request reviews in bulk from the same IP/device.
3. Don’t ask employees/family to leave fake reviews.
4. Don’t “gate” reviews (only asking happy people) using a filter that blocks negative reviews.

---

## Step 6 — Respond to every review
### Response template (5★)
“Thanks so much, {Name}! We appreciate the opportunity to help with your {service}. If you ever need an electrician in West Michigan again, we’re here for you.”

### Response template (3–4★)
“Thanks for the feedback, {Name}. We’re glad we could help, and we’re always working to improve. If there’s anything we can do better next time, please call us.”

### Response template (1–2★)
1. Reply within 24 hours.
2. Be calm and factual.
3. Offer to resolve offline:
“Hi {Name}, we’re sorry to hear that. We’d like to learn more and make it right if possible. Please call us at (616) 334-7159 and ask for {YourName}.”

---

## Step 7 — Weekly review routine
Every Friday:
1. Check new reviews.
2. Respond to any unanswered reviews.
3. Screenshot reviews count and average rating (optional tracking).
