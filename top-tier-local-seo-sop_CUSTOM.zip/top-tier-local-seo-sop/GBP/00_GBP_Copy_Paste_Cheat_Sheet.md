# GBP 00 — Copy/Paste Cheat Sheet (Top Tier Electrical Services)

Use this sheet while you’re inside Google Business Profile to avoid hunting for text.

---

## Core identity
- **Business name:** Top Tier Electrical Services
- **Website:** https://toptier-electrical.com
- **Phone:** (616) 334-7159
- **Primary category:** Electrician
- **Service area:** West Michigan

---

## Business description (paste into GBP “Business description”)
Top Tier Electrical Services is a licensed and insured electrician serving West Michigan. We help homeowners and small businesses with panel upgrades, EV charger installation, lighting, troubleshooting, code corrections, and safe electrical repairs. We serve Holland, Grand Rapids, Zeeland, Grand Haven, Muskegon, and nearby communities. Call (616) 334-7159 for clear estimates and reliable service.

---

## Suggested service areas to add (edit to match your real coverage)
Holland • Zeeland • Grand Haven • Muskegon • Grand Rapids • Wyoming • Kentwood • Jenison • Hudsonville • Allendale • Byron Center • Caledonia • Rockford • Walker • Spring Lake • Norton Shores • Fruitport • Coopersville • Ada • Comstock Park

---

## Services to add in GBP “Services”
- Panel upgrades
- EV charger installation
- Electrical troubleshooting
- Lighting installation
- Outlet & switch replacement
- Ceiling fan installation
- Whole-home surge protection
- Generator interlock / hookup (only if you offer)

---

## Post cadence (simple)
- **1 Google Post per week**
- **3 photos per week**
- **Ask for reviews after every completed job**
