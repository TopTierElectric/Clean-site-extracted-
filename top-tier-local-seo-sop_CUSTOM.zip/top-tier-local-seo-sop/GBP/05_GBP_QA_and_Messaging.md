# GBP 05 — Q&A + Messaging SOP (Exact Steps)

## Goal
Answer customer objections before they call, and capture leads via messaging.

---

## Part A — Q&A (Questions & Answers)

### Step 1 — Find your public listing
1. Open Google Maps in Incognito.
2. Search your business name.
3. Open your listing panel.

### Step 2 — Add your own questions (seeding)
Google doesn’t always let owners “seed” Q&A directly from the manager.
If needed:
1. Use a personal Google account (not your GBP owner login).
2. On the listing, find **Questions & answers**.
3. Click **Ask a question**.
4. Ask one of the questions below.
5. Switch to your owner account and answer it.

### Step 3 — Post these 10 Q&As (copy/paste)

1) **Do you offer free estimates?**  
Answer: We provide clear estimates for most projects. Call (616) 334-7159 and we’ll ask a few questions to give you a fast, accurate quote.

2) **What areas do you serve?**  
Answer: We serve West Michigan including Holland, Zeeland, Grand Rapids, Grand Haven, Muskegon and nearby communities.

3) **Are you licensed and insured?**  
Answer: Yes — we are licensed and insured in Michigan.

4) **Do you install EV chargers?**  
Answer: Yes — we install Level 2 EV chargers and dedicated circuits for safe, reliable charging.

5) **Can you upgrade electrical panels?**  
Answer: Yes — we handle panel upgrades, breaker replacements, and related code corrections.

6) **Do you handle troubleshooting for flickering lights and tripping breakers?**  
Answer: Yes — we diagnose electrical issues and recommend the safest fix.

7) **Do you do residential and small commercial work?**  
Answer: Yes — we serve homeowners and small businesses across West Michigan.

8) **Do you offer emergency service?**  
Answer: If you have an urgent electrical issue, call us and we’ll let you know the soonest availability.

9) **Do you install recessed lighting and fixtures?**  
Answer: Yes — we install fixtures, recessed lighting, dimmers, and more.

10) **How do I book an appointment?**  
Answer: Call (616) 334-7159 or request a quote on our website.

---

## Part B — Messaging

### Step 1 — Turn messaging on
1. Open GBP Manager.
2. Find **Messages**.
3. Turn on **Chat/Messaging**.

### Step 2 — Set your welcome message
Copy/paste template:
“Thanks for reaching out to Top Tier Electrical Services. Tell us your city and what you need help with (panel, EV charger, lighting, troubleshooting), and we’ll reply ASAP.”

### Step 3 — Response rule
- Reply within **5–15 minutes** during business hours whenever possible.
- If you can’t reply quickly, turn messaging off rather than leaving messages unanswered.

---

## Part C — Add “Request a Quote” workflow
1. Create a simple quote form on your website (Name, Phone, City, Service Needed, Photos).
2. Link to it from:
   - Website header button
   - GBP “Appointment/Quote” link (if available)
