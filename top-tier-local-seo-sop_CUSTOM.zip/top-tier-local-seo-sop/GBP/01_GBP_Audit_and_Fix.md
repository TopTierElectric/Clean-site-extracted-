# GBP 01 — Audit + Fix Core Profile Settings (Exact Steps)

## Goal
Make your Google Business Profile (GBP) complete, accurate, and aligned with West Michigan searches.

---

## Step 1 — Log into GBP Manager
1. Go to Google.
2. Search “Google Business Profile”.
3. Click **Manage now**.
4. Select your business listing.

---

## Step 2 — Confirm your business name
1. In the left menu, click **Edit profile**.
2. Click **Business information**.
3. Find **Business name**.
4. Verify it matches your chosen public name from 00_Project_Setup.md exactly.
5. If you change it:
   - Save
   - Expect Google may review/approve changes (this is normal).

---

## Step 3 — Confirm the primary category
1. In **Edit profile** → **Business information**.
2. Locate **Business category**.
3. Set **Primary category** to: **Electrician**
4. Add secondary categories ONLY if truly accurate (choose 1–3 max). Examples:
   - Electrical installation service
   - Electrical repair shop / service
   - Lighting contractor (only if you do a lot of lighting work)
5. Save.

---

## Step 4 — Service area setup (West Michigan)
1. In **Edit profile** → **Location**.
2. Choose whether you are:
   - **Service-area business** (you go to customers)
   - Or have a storefront/office where customers visit
3. If you are service-area:
   - Add up to ~20 service areas (cities/ZIPs)
4. Suggested West Michigan service areas (edit to match your real coverage):
   - Holland
   - Zeeland
   - Grand Haven
   - Muskegon
   - Grand Rapids
   - Wyoming
   - Kentwood
   - Jenison
   - Hudsonville
   - Allendale
   - Byron Center
   - Caledonia
   - Rockford
   - Walker
   - Spring Lake
   - Norton Shores
   - Fruitport
   - Coopersville
   - Ada
   - Comstock Park
5. Save.

---

## Step 5 — Add hours (and special hours)
1. In **Edit profile** → **Hours**.
2. Confirm your standard weekly hours.
3. Set **Holiday hours** when applicable (don’t leave blank on major holidays).
4. Save.

---

## Step 6 — Add your business description (750 characters)
1. In **Edit profile**, find **Business description**.
2. Add a clear, local, service-based description.
3. Copy/paste template (edit for accuracy):

**Template:**
Top Tier Electrical Services is a licensed and insured electrician serving West Michigan. We help homeowners and small businesses with panel upgrades, EV charger installation, lighting, troubleshooting, code corrections, and safe electrical repairs. We serve West Michigan including Holland, Grand Rapids, Zeeland, Grand Haven, Muskegon, and nearby communities. Call (616) 334-7159 for clear estimates and reliable service.

4. Save.

---

## Step 7 — Add website + phone + appointment link
1. In **Edit profile** → **Contact**:
   - Website: https://toptier-electrical.com
   - Phone: 616-334-7159
2. If you use an online scheduler:
   - Add “Appointment link”
3. Save.

---

## Step 8 — Add attributes (if available)
1. In **Edit profile** → **More** → **Attributes** (wording may vary).
2. Enable relevant attributes, e.g.:
   - Online estimates
   - Locally owned
   - Veteran-owned (only if true)
3. Save.

---

## Step 9 — Add opening date
1. In **Edit profile** → **Business information** → **Opening date**.
2. Add the real start date (month/year).
3. Save.

---

## Step 10 — Add 3 “Products” (optional but helpful)
Some GBPs allow “Products” even for services.
1. Open **Edit products**.
2. Add 3–6 “products” that are really service packages. Example:
   - Panel Upgrade Estimate
   - EV Charger Installation
   - Troubleshooting Call
3. Add:
   - A photo
   - A short description
   - A “Learn more” link to the matching page on your website
4. Save.

---

## Step 11 — Take an “after” screenshot
1. Search your business name in an Incognito window.
2. Screenshot your listing and new details.
3. Save to your “01 GBP Screenshots” folder.
