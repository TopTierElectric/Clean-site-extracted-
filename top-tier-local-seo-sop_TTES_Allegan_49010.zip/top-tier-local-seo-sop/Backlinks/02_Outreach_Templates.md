# Backlinks 02 — Outreach Templates (Copy/Paste)

## Template A — Partner testimonial request
Subject: Quick testimonial + link?

Hi {Name},  
We enjoyed working with you on {project}. If you’re open to it, we’d be happy to write a short testimonial you can post on your website.  
If you include our business name and a link to our site, it helps local West Michigan homeowners find us.

Here’s a draft you can use:
“Top Tier Electrical Services was professional, on time, and delivered clean, code-compliant work. We’d recommend them for electrical projects in West Michigan.”

Website: https://toptier-electrical.com

Thanks,  
{YourName}

---

## Template B — Chamber/association listing
Subject: Business directory listing request

Hello,  
I’d like to be listed in your business directory under “Electrician”.

Business name: Top Tier Electrical Services  
Phone: (616) 334-7159  
Website: https://toptier-electrical.com  
Service area: West Michigan (Holland, Grand Rapids, Zeeland, Grand Haven, Muskegon)

Thank you,  
{YourName}

---

## Template C — Sponsor request (link included)
Subject: Sponsorship link details

Hi {Name},  
Thanks for having us as a sponsor. When you add our sponsor listing, can you include our website link?

Top Tier Electrical Services  
(616) 334-7159  
https://toptier-electrical.com

Thanks again,  
{YourName}
