# Backlinks 01 — Local Link Building Playbook (No Spam)

## Goal
Increase “prominence” so Google trusts your business more.

---

## Step 1 — Make a list of local link opportunities
Start with these categories:
1. Local Chamber of Commerce
2. Local business associations (BNI, networking groups)
3. Supplier partners (electrical supply houses)
4. Contractors you work with (builders, remodelers, HVAC)
5. Realtors / home inspectors
6. Sponsorship pages (sports teams, charity events)
7. Local news/community sites (press releases or features)

Create your list:
- Opportunity 1: ____________
- Opportunity 2: ____________
- Opportunity 3: ____________

---

## Step 2 — Create 1 “Linkable asset” page on your site
Make a page like:
- “Electrical Safety Checklist for West Michigan Homeowners”
This gives people a reason to link to you.

---

## Step 3 — Ask for links the easy way
Whenever you complete work for another business:
1. Ask for a testimonial.
2. Offer 2–3 sentences.
3. Ask them to place it on their website with a link back.

---

## Step 4 — Sponsor something local (fastest legit links)
1. Pick a small local sponsor (youth sports, charity).
2. Ensure they have a sponsor page with links.
3. Sponsor and request they add:
   - Your business name
   - Phone
   - Website link

---

## Step 5 — Track links earned
Log:
- Site name
- Link URL
- Date earned
- Type (sponsor, partner, association)

---

## Success criteria
✅ 5–10 quality local links/mentions in 90 days.
