# Citations 01 — NAP Standard (Copy/Paste)

## Goal
Your Name / Address / Phone must match everywhere.

Use this exact text in every directory listing (edit street address only if you publish it):

**Business name:** Top Tier Electrical Services  
**Phone:** (616) 334-7159  
**Website:** https://toptier-electrical.com  

**Address policy (choose one):**
- ✅ Service-area business (no public street address)
- Publish full address

**Base location (recommended for consistency):**
- Based in: Allegan, MI 49010

> Only use Allegan, MI 49010 if it is truly your operating base. Otherwise, replace with your real base city/ZIP.

**Short business description (Directory version, 150–250 chars):**
Licensed & insured electrician serving West Michigan. Panel upgrades, EV chargers, lighting, troubleshooting, and reliable electrical repairs.

**Long description (300–750 chars):**
Top Tier Electrical Services provides licensed electrical service across West Michigan, including Allegan, Holland, Grand Rapids, Zeeland, Grand Haven, and Muskegon. We handle panel upgrades, EV charger installs, lighting, troubleshooting, code corrections, and more. Call (616) 334-7159 for clear estimates and clean workmanship.

---

## Rules (don’t skip)
1. Use the SAME phone number everywhere.
2. Use the SAME website URL everywhere.
3. Use the SAME spelling/punctuation in your business name everywhere.
4. If you change your GBP name, update citations to match (and vice versa).
