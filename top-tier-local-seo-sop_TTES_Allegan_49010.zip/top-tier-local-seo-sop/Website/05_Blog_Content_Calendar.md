# Website 05 — Content Calendar SOP (12 blog ideas)

## Goal
Publish content that earns local trust and long-tail traffic.

---

## Posting plan
- 1 post per month (minimum)
- Keep posts 800–1200 words
- Include 3–5 photos
- Add internal links to service pages

---

## 12 local content ideas (copy)
1. “How to Know If You Need a Panel Upgrade in West Michigan Homes”
2. “EV Charger Installation: What West Michigan Homeowners Should Expect”
3. “Why Breakers Trip: 7 Common Causes and What to Do”
4. “GFCI Outlets Explained: Where You Need Them (Michigan Homes)”
5. “Recessed Lighting Installation: Cost, Layout, and Common Mistakes”
6. “Is Your Home Ready for a Hot Tub? Electrical Requirements”
7. “Whole-Home Surge Protection: Is It Worth It?”
8. “Aluminum Wiring in Older Michigan Homes: What to Know”
9. “Can You Add Outlets Without Tearing Up Walls? (Common Options)”
10. “Generator Interlock vs Transfer Switch: What’s Best?”
11. “Electrical Safety Checklist for New Homeowners (West Michigan)”
12. “Top Causes of Flickering Lights (and when to call an electrician)”

---

## Step-by-step for each post
1. Pick topic from list.
2. Create outline:
   - Problem
   - Risks
   - Options
   - What you recommend
   - CTA
3. Write post.
4. Add internal links to relevant service pages.
5. Add a CTA block at end:
   - “Need help? Call (616) 334-7159”
6. Publish.
7. Request indexing in Search Console.
8. Create a Google Post linking to the new blog post (GBP folder).
