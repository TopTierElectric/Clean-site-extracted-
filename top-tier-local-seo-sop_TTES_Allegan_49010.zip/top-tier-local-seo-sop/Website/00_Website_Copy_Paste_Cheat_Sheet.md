# Website 00 — Copy/Paste Cheat Sheet (Top Tier Electrical Services)

---

## Standard NAP block (copy/paste)
**Top Tier Electrical Services**  
Phone: **(616) 334-7159**  
Website: **https://toptier-electrical.com**  
Based in **Allegan, MI 49010** • Serving **West Michigan**

> If you do not want to show the ZIP publicly, use: “Based in Allegan, MI”.

---

## Homepage brand line (add near top in plain text)
“Top Tier Electrical Services is a licensed and insured electrician based in Allegan, MI, serving West Michigan.”

---

## Footer line (keep consistent everywhere)
“Top Tier Electrical Services • (616) 334-7159 • Based in Allegan, MI • Serving West Michigan”

---

## Title tag pattern (for service pages)
“{Service} in West Michigan | Top Tier Electrical Services”

Examples:
- Panel Upgrades in West Michigan | Top Tier Electrical Services
- EV Charger Installation in West Michigan | Top Tier Electrical Services
- Electrical Troubleshooting in West Michigan | Top Tier Electrical Services

---

## Schema snippet (add to your LocalBusiness JSON-LD)
```json
"address": {
  "@type": "PostalAddress",
  "addressLocality": "Allegan",
  "addressRegion": "MI",
  "postalCode": "49010"
}
```

---

## Internal link anchors (use these words)
- EV charger installation
- panel upgrades
- electrical troubleshooting
- lighting installation
- surge protection
