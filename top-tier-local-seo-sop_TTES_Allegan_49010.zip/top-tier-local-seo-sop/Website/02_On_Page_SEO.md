# Website 02 — On-Page SEO SOP (Service Pages + Internal Linking)

## Goal
Rank for electrician services in West Michigan and your key cities.

---

## Step 1 — Confirm you have 1 page per core service
Minimum recommended:
1. Panel Upgrades
2. EV Charger Installation
3. Lighting Installation
4. Troubleshooting / Electrical Repair
5. Generator Interlock / Hookups (if you offer)
6. Surge Protection
7. Outlet/Switch Installation

If any are missing:
1. Create a new page.
2. Add 500–900 words of helpful content (not fluff).
3. Add 3–5 photos.
4. Add a call-to-action block (Call / Request Quote).

---

## Step 2 — Title tag formula (copy/paste style)
Use:
**{Service} in West Michigan | Top Tier Electrical Services**

Examples:
- Panel Upgrades in West Michigan | Top Tier Electrical Services
- EV Charger Installation in West Michigan | Top Tier Electrical Services

---

## Step 3 — H1 heading formula
Use:
**{Service} in West Michigan**

---

## Step 4 — Add city mentions naturally (no stuffing)
On each service page:
1. Mention 4–8 key cities once each (in one sentence or a list).
Example line:
“We serve Holland, Zeeland, Grand Rapids, Grand Haven, Muskegon, and nearby West Michigan communities.”

---

## Step 5 — Add “Trust” block on each service page
Include:
- Licensed & insured
- Years experience (if applicable)
- Clean workmanship
- Clear estimates

---

## Step 6 — Internal linking (THIS IS BIG)
On every page:
1. Link to 2–3 related services using descriptive anchor text.
Examples:
- “EV charger installation” links to EV page
- “panel upgrades” links to panel page
- “electrical troubleshooting” links to troubleshooting page

---

## Step 7 — Add a testimonials section
1. Add 2–5 testimonials (once you have reviews).
2. Place near the bottom of service pages.

---

## Step 8 — Add an FAQ section to each core service page
Write 4–6 FAQs per service.
Examples for EV charger:
- Do I need a panel upgrade for a Level 2 charger?
- How long does installation take?
- Can you install a charger in an outdoor location?

---

## Step 9 — Add “Request a Quote” form
1. Add a simple form:
   - Name
   - Phone
   - City
   - Service needed
   - Upload photos (optional)
2. Send submissions to your email.
3. Add a thank-you page.

---

## Step 10 — Re-submit updated pages in Search Console
1. Open Google Search Console.
2. URL Inspection.
3. Paste updated page URL.
4. Click “Request indexing”.

---

## Deliverable check
✅ Each service page:
- Has a strong title + H1
- Mentions West Michigan and key cities
- Links to other pages
- Has an FAQ + CTA
