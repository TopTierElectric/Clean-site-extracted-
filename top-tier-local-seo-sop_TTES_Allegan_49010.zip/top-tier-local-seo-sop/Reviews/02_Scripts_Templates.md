# Reviews 02 — Scripts & Templates (Copy/Paste)

## In-person ask (simple)
“Thanks again — if you felt we did a great job, would you be willing to leave a quick Google review? It really helps a small local business.”

---

## SMS template (best conversion)
“Hi {FirstName}, this is {YourName} with Top Tier Electrical Services. Thanks again for having us out today. If you have 60 seconds, could you leave us a quick Google review? Here’s the link: {ReviewLink}”

---

## SMS follow-up (48 hours)
“Hi {FirstName} — quick reminder in case it got buried. Here’s our Google review link again: {ReviewLink}. Thank you!”

---

## Email template
Subject: Quick favor — your feedback helps

Hi {FirstName},  
Thanks again for choosing Top Tier Electrical Services. If you have a moment, we’d really appreciate a quick Google review — it helps other West Michigan homeowners find us.  
{ReviewLink}

Thank you,  
{YourName}  
Top Tier Electrical Services  
(616) 334-7159

---

## Voicemail script (if you must)
“Hi {FirstName}, this is {YourName} with Top Tier Electrical Services. Thanks again for the opportunity to help today. If everything looks good, we’d really appreciate a quick Google review — I can text you the link. Thanks!”

---

## Review response templates

### 5-star
“Thanks so much, {Name}! We appreciate the opportunity to help with your {service}. If you ever need an electrician in West Michigan again, we’re here for you.”

### 4-star
“Thanks, {Name}! We appreciate the feedback and are glad we could help. If there’s anything we can do better next time, please let us know.”

### 1–3 star
“Hi {Name}, we’re sorry to hear that. We’d like to understand what happened and make it right if possible. Please call us at (616) 334-7159 and ask for {YourName}.”
