# Reviews 01 — Review Request Workflow (Exact Steps)

## Goal
Get 2–4 new Google reviews per month consistently.

---

## Step 1 — Make review requests part of your close-out routine
At the end of every job:
1. Confirm the customer is satisfied:
   - “Does everything look good on your end?”
2. If yes, ask:
   - “Would you be willing to leave a quick Google review? It really helps us in West Michigan.”

---

## Step 2 — Send the review link by text (same day)
1. Open your text messages.
2. Send the template from Reviews/02_Scripts_Templates.md
3. Include the Google review link.

---

## Step 3 — Follow-up rule (48 hours)
If no review after 48 hours:
1. Send a single polite reminder:
   “Just checking in — if you have a moment, here’s that review link again: {ReviewLink}. Thanks!”

Do not spam. One reminder only.

---

## Step 4 — Track review requests
Keep a simple log:
- Customer first name
- Date asked
- Service
- City
- Review left? (Y/N)

---

## Step 5 — Respond to reviews weekly
See GBP/06_GBP_Reviews_System.md for response templates.

---

## Goal metrics
- Month 1: 5 reviews
- Month 2: 5 reviews
- Month 3: 5 reviews

Adjust based on job volume.
