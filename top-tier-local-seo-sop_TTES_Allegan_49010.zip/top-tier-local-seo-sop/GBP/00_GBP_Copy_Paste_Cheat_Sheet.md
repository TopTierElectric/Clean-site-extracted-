# GBP 00 — Copy/Paste Cheat Sheet (Top Tier Electrical Services)

Use this file while editing your Google Business Profile.

---

## Business Name
**Top Tier Electrical Services**

## Website
**https://toptier-electrical.com**

## Phone
**(616) 334-7159**

---

## Business Description (copy/paste)
Top Tier Electrical Services is a licensed and insured electrician serving West Michigan. We help homeowners and small businesses with panel upgrades, EV charger installation, lighting, troubleshooting, code corrections, and safe electrical repairs. Based in Allegan, MI 49010, we serve Holland, Grand Rapids, Zeeland, Grand Haven, Muskegon, and nearby communities. Call (616) 334-7159 for clear estimates and reliable service.

> If your real base city/ZIP is different, replace “Allegan, MI 49010” with your true base.

---

## Primary Category
- Electrician

## Secondary Categories (choose 1–3 max, only if accurate)
- Electrical installation service
- Electrical repair service
- Lighting contractor

---

## Service Areas (suggested list)
Choose the cities you truly serve (up to Google’s limit):
- Allegan
- Otsego
- Plainwell
- Wayland
- Hamilton
- Saugatuck
- Holland
- Zeeland
- Hudsonville
- Jenison
- Allendale
- Coopersville
- Grand Haven
- Muskegon
- Grand Rapids
- Wyoming
- Kentwood
- Norton Shores

---

## Services to add (in GBP “Services”)
- Electrical troubleshooting
- Panel upgrades / breaker panel replacement
- EV charger installation (Level 2)
- Lighting installation (fixtures / recessed)
- Outlet & switch replacement
- GFCI outlets
- Ceiling fan installation
- Whole-home surge protection
- Dedicated circuits (appliances, garage, workshop)
- Code corrections

---

## Welcome message (GBP Messaging)
Thanks for contacting Top Tier Electrical Services. What city are you in, and what do you need help with (panel, EV charger, lighting, troubleshooting)? We’ll reply ASAP.

---

## Q&A (seed these questions + answers)
**Q: Are you licensed and insured?**  
A: Yes — Top Tier Electrical Services is licensed and insured in Michigan.

**Q: What areas do you serve?**  
A: We serve West Michigan including Allegan, Holland, Zeeland, Grand Rapids, Grand Haven, Muskegon and nearby communities.

**Q: Do you install EV chargers?**  
A: Yes — we install Level 2 EV chargers and dedicated circuits for safe, reliable charging.

**Q: Do you do panel upgrades?**  
A: Yes — we handle electrical panel upgrades, breaker replacements, and related code corrections.

---

## Post template (weekly)
Finished a {"SERVICE"} in {"CITY"}, MI. We {"WHAT WE DID"} and made sure everything is code-compliant and cleanly installed.  
Need help with {"RELATED SERVICE"} in West Michigan? Call (616) 334-7159.
