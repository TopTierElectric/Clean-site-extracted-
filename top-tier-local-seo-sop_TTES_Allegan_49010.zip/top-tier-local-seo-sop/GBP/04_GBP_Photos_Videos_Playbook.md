# GBP 04 — Photos & Videos SOP (Exact Steps)

## Goal
Build “visual proof” and keep your listing fresh.

---

## Step 1 — Upload your first 20 photos (day 1)
1. Open GBP Manager.
2. Click **Add photo**.
3. Upload:
   - 1 Logo (square)
   - 1 Cover photo (wide)
   - 3 “At work” photos
   - 3 Finished work photos (panel, lighting, EV charger)
   - 3 Tools / truck photos (clean and branded if possible)
   - 2 Team photos (even if it’s just you)
   - 2 Safety/compliance photos (permit, panel labeling — no personal info)
   - 5 Misc. (clean installs, tidy workspace)

---

## Step 2 — Ongoing cadence (easy plan)
- Every week: upload **3 new photos**
- Every month: upload **1 short video** (10–30 seconds)
Ideas:
- “Before/after panel upgrade”
- “EV charger final test”
- “New lighting install”

---

## Step 3 — File naming (helps organization; not required by Google)
Before uploading, name files like:
- 2026-02-TopTier-EVcharger-Holland.jpg
- 2026-02-TopTier-PanelUpgrade-GrandRapids.jpg

---

## Step 4 — Photo quality rules
1. Bright, sharp, not blurry.
2. No personal customer data.
3. Show clean workmanship.
4. Avoid stock photos.

---

## Step 5 — Track photo uploads
Log date + photo set in your tracker (optional).
