# GBP 02 — Services Setup (Exact Steps)

## Goal
Tell Google exactly what you do so you can show up for service searches (EV chargers, panel upgrades, etc.).

---

## Step 1 — Open the Services editor
1. Go to your GBP Manager.
2. Click **Edit services** (or **Services**).

---

## Step 2 — Add your core service categories
1. Add categories that match your real work.
2. Common electrician categories:
   - Electrical repair
   - Electrical installation
   - Lighting installation
   - Electrical panel upgrades
   - EV charger installation
   - Troubleshooting
   - Outlet/switch installation
   - Ceiling fan installation
   - Surge protection
   - Generator interlock / hookup

---

## Step 3 — Add service items with descriptions
For each service item:
1. Click **Add service**.
2. Enter:
   - Service name (e.g., “Panel Upgrades”)
   - Description (2–3 sentences)
3. Save.

### Copy/paste descriptions (edit for truth)
**Panel Upgrades**
Upgrade outdated electrical panels to improve safety and capacity. We handle permitting guidance, clean workmanship, and code-compliant installation for West Michigan homes.

**EV Charger Installation**
Level 2 EV charger installation for your garage or driveway. We size the circuit correctly, install dedicated breakers, and ensure safe, reliable charging.

**Electrical Troubleshooting**
Flickering lights, tripping breakers, dead outlets, or strange smells? We diagnose issues quickly and recommend the safest fix before problems get worse.

**Lighting Installation**
Indoor and outdoor lighting installs, including recessed lights, fixtures, dimmers, and smart lighting. Clean installs with attention to finish details.

**Outlet & Switch Replacement**
Replace worn outlets/switches, add GFCI protection where needed, install USB outlets, and add circuits for remodels or home offices.

**Ceiling Fans**
Install or replace ceiling fans with proper bracing, wiring, and controls so the fan runs safe and quiet.

**Surge Protection**
Whole-home surge protection to help protect appliances and electronics from spikes and surges.

---

## Step 4 — Link services to pages (if available)
Some dashboards allow you to add links.
1. If you can link, point each service to your matching service page:
   - /panel-upgrades.html
   - /ev-chargers.html
   - /lighting.html
   - /troubleshooting.html
2. Save.

---

## Step 5 — Verify services show publicly
1. In Incognito, search your business name.
2. Open your GBP.
3. Scroll to “Services” and confirm they appear.
4. Screenshot for your records.
