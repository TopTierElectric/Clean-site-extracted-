# GBP 03 — Google Posts Playbook (Exact Steps + Templates)

## Goal
Post weekly so your listing looks active, earns more engagement, and builds trust.

---

## Step 1 — Where to create a post
1. Open GBP Manager.
2. Click **Add update** / **Posts** (label varies).
3. Choose the post type:
   - What’s New
   - Offer
   - Event

---

## Step 2 — Your posting schedule (simple & realistic)
- **1 post every week** (same day each week).
- Each post should include:
  - 1 photo (real job photo)
  - 1–2 short paragraphs
  - Call-to-action button (Call Now / Learn More)

---

## Step 3 — Post writing rules
1. Keep it human.
2. Mention:
   - Service performed
   - City/area (naturally)
3. Avoid keyword stuffing.
4. Always add a CTA.

---

## Step 4 — Templates (copy/paste)

### Template A — Recent job (best for trust)
**Text:**
Finished a [SERVICE] in [CITY], MI. We [WHAT YOU DID] and made sure everything is code-compliant and cleanly installed.  
If you need help with [RELATED SERVICE], give us a call at (616) 334-7159.

**Button:** Call Now  
**Link (optional):** matching service page

Example:
Finished an EV charger install in Holland, MI. We ran a dedicated circuit, installed a new breaker, and tested charging performance.  
Need EV charger installation in West Michigan? Call (616) 334-7159.

---

### Template B — Tip post (builds authority)
**Text:**
Quick tip: If your breaker trips repeatedly, don’t keep resetting it. It’s a sign of an overloaded circuit or a wiring issue.  
We provide electrical troubleshooting across West Michigan—reach out if you want it checked safely.

**Button:** Learn More  
**Link:** /troubleshooting.html

---

### Template C — Seasonal (high engagement)
**Text:**
Winter is tough on electrical systems—space heaters and holiday lighting can overload circuits.  
If you’re seeing flickering lights or warm outlets, schedule troubleshooting before it becomes a hazard.

**Button:** Call Now

---

## Step 5 — Photo guidelines
Use real photos:
- Panel before/after (no homeowner info visible)
- EV charger finished install
- Lighting fixture installed
- You at work (PPE, clean setup)
- Branded truck if you have one

---

## Step 6 — Save & track
1. After posting, copy the post link (if available) or screenshot.
2. Log it in your tracker (date + topic).
