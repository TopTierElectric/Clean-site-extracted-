export async function onRequestPost({ request, env, waitUntil }) {
  const apiHeaders = {
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'none'",
  };
  try {
    // Parse form data
    const formData = await request.formData();
    // Honeypot check
    if (formData.get('company')) {
      return new Response('Spam detected', { status: 400, headers: apiHeaders });
    }
    const name = formData.get('name');
    const email = formData.get('email');
    const phone = formData.get('phone');
    const message = formData.get('message') || formData.get('details');
    if (!name || !(email || phone) || !message) {
      return new Response('Missing required fields', { status: 400, headers: apiHeaders });
    }
    // Turnstile verification
    const token = formData.get('cf-turnstile-response');
    if (!token || !env.TURNSTILE_SECRET_KEY) {
      return new Response('Missing Turnstile token', { status: 400, headers: apiHeaders });
    }
    const verifyResponse = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ secret: env.TURNSTILE_SECRET_KEY, response: token })
    });
    const verifyResult = await verifyResponse.json();
    if (!verifyResult.success) {
      return new Response('Failed Turnstile verification', { status: 400, headers: apiHeaders });
    }
    // Save submission to KV if available
    const submission = {
      id: crypto.randomUUID(),
      received_at: new Date().toISOString(),
      name,
      email,
      phone,
      message,
      ip: request.headers.get('CF-Connecting-IP') || '',
      userAgent: request.headers.get('User-Agent') || ''
    };
    if (env.FORM_SUBMISSIONS) {
      await env.FORM_SUBMISSIONS.put(`submission:${submission.id}`, JSON.stringify(submission), { expirationTtl: 60 * 60 * 24 * 90 });
    }
    // Optional webhook forwarding
    if (env.ZAPIER_WEBHOOK_URL) {
      waitUntil(fetch(env.ZAPIER_WEBHOOK_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(submission) }));
    }
    // Redirect to thank-you page
    return new Response('', { status: 303, headers: { Location: '/thank-you', ...apiHeaders } });
  } catch (err) {
    return new Response('Server error', { status: 500, headers: apiHeaders });
  }
}

export const onRequestGet = () => new Response('Method Not Allowed', { status: 405, headers: { Allow: 'POST' } });
